# SerialCom

Interface gráfica moderna e elegante para comunicação serial via picocom.

## Características

- Interface gráfica moderna com PyQt6
- Design elegante e responsivo
- Detecção automática de portas seriais com QSerialPortInfo
- Suporte para portas seriais (/dev/ttyS*) e adaptadores USB (/dev/ttyUSB*)
- Configuração completa de parâmetros seriais:
  - Velocidade (baud rate) - 300 a 921600 bps
  - Bits de dados (5-8)
  - Paridade (None, Even, Odd)
  - Bits de parada (1-2)
  - Controle de fluxo (None, Hardware, Software)
- Detecção automática de portas disponíveis
- Solicitação de senha root via sudo
- Abertura no terminal padrão do sistema

## Requisitos

- Python 3
- PyQt6
- Qt6 SerialPort (opcional, para detecção avançada de portas)
- picocom
- sudo configurado

## Instalação

1. Instalar as dependências (se ainda não estiver instalado):
```bash
# Arch Linux / Manjaro
sudo pacman -S python-pyqt6 qt6-serialport picocom

# Fedora / RHEL
sudo dnf install python3-pyqt6 python3-pyqt6-sip picocom

# Debian / Ubuntu
sudo apt install python3-pyqt6 python3-pyqt6.qtserialport picocom
```

2. Tornar os scripts executáveis:
```bash
chmod +x serial_gui.py serial-terminal
```

3. (Opcional) Instalar no menu de aplicações:
```bash
./install.sh
```

## Uso

Execute a aplicação:
```bash
# Forma recomendada
./serialcom

# Diretamente
./serial_gui.py

# Ou via Python
python3 serial_gui.py
```

### Configuração

1. Selecione o tipo de porta (Serial ou USB)
2. Escolha a porta específica na lista
3. Configure a velocidade de comunicação (campo principal)
4. Ajuste os demais parâmetros conforme necessário
5. Clique em "CONECTAR"
6. Insira a senha de root quando solicitado
7. O terminal picocom será aberto em uma nova janela

### Comandos do picocom

No terminal picocom, use:
- `Ctrl+A` `Ctrl+X` - Sair do picocom
- `Ctrl+A` `Ctrl+H` - Ajuda com todos os comandos

## Permissões

Para evitar solicitar senha toda vez, você pode adicionar seu usuário ao grupo dialout:
```bash
sudo usermod -a -G dialout $USER
```

Após isso, faça logout e login novamente para aplicar as mudanças.

## Solução de Problemas

### Porta não aparece na lista
- Verifique se o dispositivo está conectado
- Execute `ls -la /dev/ttyUSB* /dev/ttyS*` para ver portas disponíveis
- Pode ser necessário carregar módulos do kernel

### Permissão negada
- Certifique-se de que está usando sudo
- Verifique se seu usuário tem permissões para usar sudo
- Ou adicione seu usuário ao grupo dialout (veja acima)

### Terminal não abre
- Verifique se possui um terminal instalado (gnome-terminal, konsole, xterm, etc.)
- Instale um terminal se necessário: `sudo dnf install gnome-terminal`
