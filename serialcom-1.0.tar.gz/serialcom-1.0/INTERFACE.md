# Interface Gráfica - Visual da Aplicação

## Layout da Janela

```
┌─────────────────────────────────────────────────────────┐
│                       SerialCom                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│                     SerialCom                          │
│                                                         │
│  ┌────────────────────────────────────────────────┐   │
│  │  Configuração de Porta                        │   │
│  ├────────────────────────────────────────────────┤   │
│  │                                                │   │
│  │  Tipo de Porta:    [USB (/dev/ttyUSB*)    ▼] │   │
│  │                                                │   │
│  │  Porta:            [/dev/ttyUSB0           ▼] │   │
│  │                                                │   │
│  └────────────────────────────────────────────────┘   │
│                                                         │
│  ┌────────────────────────────────────────────────┐   │
│  │  Parâmetros de Comunicação                    │   │
│  ├────────────────────────────────────────────────┤   │
│  │                                                │   │
│  │  Velocidade (baud): [115200               ▼]  │   │
│  │                     └─────────────────────┘   │   │
│  │                      (campo destacado em azul)│   │
│  │                                                │   │
│  │  Bits de Dados:     [8                     ▼] │   │
│  │                                                │   │
│  │  Paridade:          [None                  ▼] │   │
│  │                                                │   │
│  │  Bits de Parada:    [1                     ▼] │   │
│  │                                                │   │
│  │  Controle de Fluxo: [None                  ▼] │   │
│  │                                                │   │
│  └────────────────────────────────────────────────┘   │
│                                                         │
│            ┌───────────────────────────┐               │
│            │      CONECTAR             │               │
│            └───────────────────────────┘               │
│               (botão verde grande)                     │
│                                                         │
│              Pronto para conectar                      │
│              (status em verde)                         │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Características Visuais

### Cores e Estilos

- **Fundo**: Cinza claro (#f5f5f5)
- **Grupos**: Fundo branco com bordas arredondadas
- **Campo de Velocidade**: Destaque em azul (#e3f2fd) com borda azul (#2196f3)
- **Botão Conectar**: Verde (#4caf50) com efeito hover
- **Status**:
  - Verde: Pronto
  - Laranja: Conectando
  - Azul: Aguardando senha
  - Vermelho: Erro

### Interações

1. **Hover sobre ComboBox**: Borda muda para azul
2. **Hover sobre Botão**: Verde mais escuro
3. **Click no Botão**: Verde ainda mais escuro
4. **Mudança de Tipo de Porta**: Atualiza automaticamente a lista

### Diálogos

Quando você clica em CONECTAR:

```
┌─────────────────────────────────────┐
│  ⓘ  Conexão Iniciada                │
├─────────────────────────────────────┤
│                                     │
│  Terminal picocom aberto.           │
│                                     │
│  Porta: /dev/ttyUSB0                │
│  Velocidade: 115200 baud            │
│  Configuração: 8N1                  │
│                                     │
│  Use Ctrl+A Ctrl+X para sair        │
│  do picocom                         │
│                                     │
│           ┌────────┐                │
│           │   OK   │                │
│           └────────┘                │
└─────────────────────────────────────┘
```

### Responsividade

- Tamanho fixo: 550x500 pixels
- Espaçamento consistente: 15-20px
- Campos com altura mínima adequada
- Labels alinhados à esquerda
- Inputs ocupam toda a largura disponível

## Fluxo de Uso

1. **Seleção de Porta**
   - Escolha entre Serial ou USB
   - Lista atualiza automaticamente
   - Contador de portas no status

2. **Configuração**
   - Velocidade é o campo principal (destacado)
   - Valores padrão seguros (9600, 8N1)
   - Todos os combos com opções comuns

3. **Conexão**
   - Click no botão verde
   - Status muda para "Conectando..."
   - Terminal abre automaticamente
   - Diálogo informativo aparece
   - Status indica "insira senha"

4. **Terminal picocom**
   - Abre em janela separada
   - Solicita senha sudo
   - Inicia comunicação serial
   - Ctrl+A Ctrl+X para sair
